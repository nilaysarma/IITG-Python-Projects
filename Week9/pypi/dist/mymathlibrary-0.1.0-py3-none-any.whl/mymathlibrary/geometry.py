def area_circle(a):
    return 3.14 * a * a

def area_square(a):
    return a * a

def area_rectangle(a, b):
    return a * b
