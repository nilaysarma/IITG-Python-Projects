def area_circle(a):
    """Returns the area of a circle."""
    return 3.14 * a * a

def area_square(a):
    """Returns the area of a square."""
    return a * a

def area_rectangle(a, b):
    """Returns the area of a rectangle."""
    return a * b
